ExecCommandHelper
=====
引数がたくさんあるコンソールアプリケーションを実行するツールです。  
コマンドラインが長くなり、引数を指定するのが面倒なので作成しました。  

必要環境
-----
.NET FrameWork4.0

対応OS
-----
.NET Frameworkの必要環境と同じです。

インストール方法
-----
ファイルを展開するだけです。

アンインストール方法
-----
ファイル削除のみでＯＫです。レジストリは使っていません。  

<img src="http://www.geocities.jp/tripod31hoge/images/execcommandhelper.png">


